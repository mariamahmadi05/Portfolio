let xpos = 300;
let ypos = 200;
let dx = 5;
let dy = 4;
let score1 = 0;
let score2 = 0;

let gameState = "start"; // Game states: "start", "play", "end"

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);

  if (gameState === "start") {
    drawStartScreen();
  } else if (gameState === "play") {
    playGame();
  } else if (gameState === "end") {
    drawEndScreen();
  }
}

function drawStartScreen() {
  textSize(32);
  fill(255);
  textAlign(CENTER, CENTER);
  text("Pong Game", width / 2, height / 3);
  textSize(24);
  text("Press Enter to Play", width / 2, height / 2);
}

function drawEndScreen() {
  textSize(32);
  fill(255);
  textAlign(CENTER, CENTER);
  if (score1 > score2) {
    text("Player 1 Wins!", width / 2, height / 3);
  } else {
    text("Player 2 Wins!", width / 2, height / 3);
  }
  textSize(24);
  text("Press Enter to Restart", width / 2, height / 2);
}

function playGame() {
  // Draw paddles
  fill(255);
  rect(10, constrain(mouseY, 0, height - 70), 10, 70); // Left paddle (mouse-controlled)
  rect(580, ypos - 35, 10, 70); // Right paddle (follows ball)

  // Draw centerline
  for (let i = 0; i < height; i += 50) {
    rect(300, i, 2, 30);
  }

  // Draw scores
  textSize(100);
  fill(50);
  text(score1, 120, 240);
  text(score2, 420, 240);

  // Draw ball
  fill(255);
  ellipse(xpos, ypos, 20, 20);

  // Update ball position
  xpos += dx;
  ypos += dy;

  // Ball collision with top and bottom walls
  if (ypos <= 10 || ypos >= height - 10) {
    dy = -dy;
  }

  // Ball collision with paddles
  if (
    xpos <= 20 && ypos > mouseY && ypos < mouseY + 70 // Left paddle
  ) {
    dx = -dx;
    xpos = 20; // Avoid ball getting stuck
  }

  if (
    xpos >= 570 && ypos > ypos - 35 && ypos < ypos + 35 // Right paddle
  ) {
    dx = -dx;
    xpos = 570; // Avoid ball getting stuck
  }

  // Scoring logic
  if (xpos < 0) {
    score2++;
    checkGameEnd();
    resetBall();
  }

  if (xpos > width) {
    score1++;
    checkGameEnd();
    resetBall();
  }
}

function checkGameEnd() {
  if (score1 >= 5 || score2 >= 5) {
    gameState = "end";
  }
}

// Reset ball to center
function resetBall() {
  xpos = width / 2;
  ypos = height / 2;
  dx = random([-5, 5]); // Randomize initial direction
  dy = random([-4, 4]);
}

// Handle key presses
function keyPressed() {
  if (keyCode === ENTER) {
    if (gameState === "start" || gameState === "end") {
      gameState = "play";
      score1 = 0;
      score2 = 0;
      resetBall();
    }
  }
}
