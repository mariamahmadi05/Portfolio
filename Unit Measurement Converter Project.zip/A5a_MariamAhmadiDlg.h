
// A5a_MariamAhmadiDlg.h : header file
//

#pragma once


// CA5aMariamAhmadiDlg dialog
class CA5aMariamAhmadiDlg : public CDialogEx
{
// Construction
public:
	CA5aMariamAhmadiDlg(CWnd* pParent = nullptr);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_A5A_MARIAMAHMADI_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedEdit3();
	CEdit m_input;
	CEdit m_output;
	afx_msg void OnBnClickedCmToInch();
	afx_msg void OnBnClickedInchToCm();
};
